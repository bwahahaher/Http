package com.example.httpexample.domain.user;

public class Company {
    public final String name;
    public final String catchPhrase;
    public final String bs;

    public Company(String name, String catchPhrase, String bs) {
        this.name = name;
        this.catchPhrase = catchPhrase;
        this.bs = bs;
    }
}
