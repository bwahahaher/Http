package com.example.httpexample.domain.user;

public class Geo {
    public final double lat;
    public final double lng;

    public Geo(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }
}
