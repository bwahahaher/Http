package com.example.httpexample.view;

public class Recycle {

    private String name;
    private String company, id, email, address, phone,  website,  username;


    public Recycle(String name, String company, String id, String email, String address, String phone, String website, String username ){

        this.name=name;
        this.company = company;
        this.id = id;
        this.email=email;
        this.company = company;
        this.address = address;
        this.phone = phone;
        this.website = website;
        this.username = username;


    }
    public String getName() {
        return this.name;
    }
    public String getId() {
        return this.id;
    }
    public String getCompany() {
        return this.company;
    }


}