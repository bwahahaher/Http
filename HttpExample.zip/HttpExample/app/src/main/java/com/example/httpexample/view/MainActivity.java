package com.example.httpexample.view;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.TextView;

import com.example.httpexample.R;
import com.example.httpexample.interactor.user.UserInteractor;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {
    List<Recycle> recycleList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView userNameTextView = findViewById(R.id.userNameTextView);
        new UserInteractor(userNameTextView).getUsers();
        setInitialData();
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.list);
        // создаем адаптер
        DataAdapter adapter = new DataAdapter(this, recycleList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        // устанавливаем для списка адаптер
        recyclerView.setAdapter(adapter);
    }


    private void setInitialData() {


        recycleList.add(new Recycle("name:", "company:", "2", "Email:","Address:","Phone:", "Website:", "Username:"));
    }
}